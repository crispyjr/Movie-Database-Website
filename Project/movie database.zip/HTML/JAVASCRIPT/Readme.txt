My Movie Database Readme File

Note: Kept getting errors with CORS whcih didnt allow me to go further with the xmlhttp. Also use npm install for express.

List of Files: 1. MMDB_Home.html - Home page for the movie. Major changes: Slideshow now added, links to movies and actors shall be included when the template is set up. Click the little buttons or the side arrows to check each other slide.  
	       2. MMDB_Lists.html - No changes. 
               3. MMDB_logIn.html - Page to log in. SignIn button should change the top button to MYAccount.
               4. MMDB_movie.html - Movie should show both the castandcrew panel, the reviews and the details. Details wont have any js included so for now the design is incomplete.
               5. MMDB_actor.html - Actor image, with a list of the movies they've been in. More to be included when JSON is connected.
               6. MMDB_Register.html - User registration page, when press register, should be redirected to the home page where the sign in button is changed to myAccount.
               7. MMDB_base.html - base html for search bar template
	       8. Folder/ Images - All the images included to the pages
               9. CSS Folder - CSS files stored
	       10. base.css - base css code design for other webpades. .
	       11. signIn.css - css for the design for logIn.html and register.html.
	       12. Home.css - Styling for the homepage. More styling to be expected. 
	       13. Account.css - Styling for the account page
	       14. movie.css - styling for the movie page. Details panel to be edited.
	       15. actors.css - styling for the actor page.
	       16. MMDB.js - Javascript for the functions of buttons.
	       17. MMDBserver.js - Server using node, some images dont load, no idea why so i created an express server as well.
               18. mmserver.js - the express server. 
	       19. MMDB_edit.html - page where you should edit the movies or add a new movie
	       20. slideshow.js - controls the slideshow for home page
	       21. mmdbEvery.js - signup and login functions as well as checking for password.
               22. movies folder - list of json files containing the short movie json file
               23. JSON folder - list of json files 
               24. edit.css - design for edit page
Name of project: Movie Database

Name of partners: Just myself.

